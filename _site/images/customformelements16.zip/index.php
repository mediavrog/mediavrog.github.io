<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Die ist eine Testseite f�r custom Form Elements - Checkboxen und Radiobuttons selbst per CSS gestalten / Test custom Form Elements</title>

<link rel="stylesheet" type="text/css" href="customFormElements.css" />
<script type="text/javascript" src="mootools.v1.11.js"></script>
<?php
if($_GET['accordion'] == yes){
 echo '<script type="text/javascript" src="002accordion.js"></script>';
} ?>

<script type="text/javascript" src="class.customFormElements.js"></script>
<script type="text/javascript">
window.addEvent('domready', function(){new customFormElements();});
</script>

</head>

<body>


<p>Dies ist eine Testseite f�r die Javascript-Klasse (basierend auf mootools) customFormElements, welche das Anpassen von Checkboxen und Radiobuttons per Javascript erm�glicht.</p>
<p>Dieses Script und die Ressourcen k�nnen frei verwendet werden solange meine kleine Copyright Anmerkung intakt bleibt.<br />Grafiken der Buttons und Boxen in Anlehnung an den Opera :) .<a href="http://mediavrog.net/blog/2007/06/06/mootools/mootools-customformelements-checkboxen-und-radiobuttons-selbst-per-css-gestalten/" >Weitere Infomationen im Blog von mediaVROG erfahren</a>.
</p>
<hr />
<p>This is a demopage for my little javascript-class (based on mootools) customFormElements, which gives you the opportunity to style your own checkboxes and radiobuttons via css.</p>
<p>You may use, modify and alter any parts of this script and/or ressources as long as you leave my little copyright notice intact.<br />The gfx follow the opera gfx a bit :) .<a href="http://mediavrog.net/blog/2007/06/06/mootools/mootools-customformelements-checkboxen-und-radiobuttons-selbst-per-css-gestalten/" >Read more in my blog (german)</a>.
</p>
<hr />

<p><a href="class.customFormElements.js">View JS</a></p>

<?php
if($_GET['accordion'] == yes){
 echo '<p><a href="index.php?accordion=no" title="Disable Accordion effect">&raquo; Disable accordion effect</a></p>';
}else{
 echo '<p><a href="index.php?accordion=yes" title="Enable Accordion effect">&raquo; Enable accordion effect</a></p>';
} ?>

<p>Postvariables:</p>
<pre>
<?php var_dump($_POST); ?>
</pre>

<form id="form" method="post" action="#">
<fieldset><legend class="tog">Replaced checkboxes</legend>
<ul class="box">
	<li><label for="chb1">Checkbox #1 - checked by default</label><input id="chb1" type="checkbox" <?php if($_POST['checkbox1'] || $_SERVER['REQUEST_METHOD'] != "POST"){echo 'checked="checked" ';}?>value="Checkbox1:Great!" name="checkbox1" />
		</li>

	<li><label for="chb2">Checkbox #2</label><input id="chb2" type="checkbox" <?php if($_POST['checkbox2']){echo 'checked="checked" ';}?>value="Checkbox2:Wow!" name="checkbox2" /></li>

	<li><label for="chb3">Checkbox #3</label><input id="chb3" type="checkbox" value="Checkbox3:Fascinating!" name="checkbox3" <?php if($_POST['checkbox3']){echo 'checked="checked" ';}?> /></li>

</ul>
</fieldset>

<fieldset><legend class="tog">Replaced radiobuttons</legend>
<ul class="box">
	<li><label for="rb1">Radiobutton #1 - checked by default</label><input id="rb1" type="radio" <?php if($_POST['radio']=="1:Choice1:Hooray!" || $_SERVER['REQUEST_METHOD'] != "POST"){echo 'checked="checked" ';}?>value="1:Choice1:Hooray!" name="radio" />
		</li>

	<li><label for="rb2">Radiobutton #2</label><input id="rb2" type="radio" <?php if($_POST['radio'] == "1:Choice2:Woot!"){echo 'checked="checked" ';}?>value="1:Choice2:Woot!" name="radio" />
		</li>

	<li><label for="rb3">Radiobutton #3</label><input id="rb3" type="radio" value="1:Choice3:Trembling!" name="radio" <?php if($_POST['radio'] == "1:Choice3:Trembling!"){echo 'checked="checked" ';}?> />
		</li>

</ul>
</fieldset>

<fieldset><legend class="tog">2nd group of Replaced radiobuttons</legend>
<ul class="box">
	<li><label for="rb2-1">Radiobutton #1 - checked by default</label><input id="rb2-1" type="radio" <?php if($_POST['radio2']["hallo"]=="2:Choice1:Hooray!" || $_SERVER['REQUEST_METHOD'] != "POST"){echo 'checked="checked" ';}?>value="2:Choice1:Hooray!" name="radio2[hallo]" />
		</li>

	<li><label for="rb2-2">Radiobutton #2</label><input id="rb2-2" type="radio" <?php if($_POST['radio2']["hallo"] == "2:Choice2:Woot!"){echo 'checked="checked" ';}?>value="2:Choice2:Woot!" name="radio2[hallo]" />
		</li>

	<li><label for="rb2-3">Radiobutton #3</label><input id="rb2-3" type="radio" value="2:Choice3:Trembling!" name="radio2[hallo]" <?php if($_POST['radio2']["hallo"] == "2:Choice3:Trembling!"){echo 'checked="checked" ';}?> />
		</li>

</ul>
</fieldset>

<fieldset><legend>Check POST Data</legend>
<input type="submit" />
</fieldset>

</form>
</body></html>