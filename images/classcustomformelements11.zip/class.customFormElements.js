/*
customFormElements 1.1 - style checkboxes and radiobuttons on your own
by Maik Vlcek (http://www.mediavrog.net) - MIT-style license.
Copyright (c) 2007 Maik vlcek

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

var customFormElements = new Class({
	
	initialize: function(props){
		
		this.props = Object.extend({
			scope: false,
			check: true,
			radio: true
		}, props || {});
		
		/* Procede Checkboxes */
		if(this.props.check == true){
			//console.log("call customCheckboxes");
			$ES("input[type=checkbox]",this.props.scope || document.body).each(function(el,i){
				
				var pos = el.getPosition();
				
				var jschb = new Element("div",{
							"styles":{
								position: "absolute",
								top: pos.y-3,
								left: pos.x
							},
							"class": "jsCheckbox"}).injectInside(document.body);
				
				jschb.addEvents({"mouseover":this.cbHover.pass(el,jschb),"mouseout":this.cbMouseOut.pass(el,jschb),"click":this.cbClicked.pass(el,jschb)});
	
				el.checked?jschb.addClass("jsCheckboxActive"):"";
				el.setStyle("visibility","hidden");
				
			}.bind(this));
		}
		
		/* Procede Radiobuttons */
		if(this.props.radio == true){
			
			this.radios = new Array();
			
			//console.log("call customRadiobuttons");
			$ES("input[type=radio]",this.props.scope || document.body).each(function(el,i){
						
				var elName = el.getProperty("name");
				var pos = el.getPosition();
				
				var jschb = new Element("div",{
							"styles":{
								position: "absolute",
								top: pos.y-3,
								left: pos.x
							},
							"class": "jsRadiobutton"}).injectInside(document.body);
				
				jschb.addEvents({"mouseover":this.rbHover.pass([el,jschb],this),"mouseout":this.rbMouseOut.pass([el,jschb],this),"click":this.rbClicked.pass([el,jschb],this)});
				jschb.addClass("cfe_radiogroup_"+elName);
				
				el.addClass("cfe_radio_"+elName);
				el.checked?jschb.addClass("jsRadiobuttonActive"):"";
				el.setStyle("visibility","hidden");

			}.bind(this));
		}
	},
	
	cbHover: function(el){this.addClass(el.checked?"jsCheckboxHoverActive":"jsCheckboxHover");},
	cbMouseOut: function(el){this.removeClass(el.checked?"jsCheckboxHoverActive":"jsCheckboxHover");},
	cbClicked: function(el){
		if(el){
			this.fireEvent("mouseout");
			
			if(el.checked){
				el.removeProperty("checked");
				this.removeClass("jsCheckboxActive");
			}
			else{
				el.checked = "true";
				this.addClass("jsCheckboxActive");
			}
		}
	},
	
	rbHover: function(el,nel){
		nel.addClass(el.checked?"jsRadiobuttonHoverActive":"jsRadiobuttonHover");
	},
	rbMouseOut: function(el,nel){
		nel.removeClass(el.checked?"jsRadiobuttonHoverActive":"jsRadiobuttonHover");
		nel.removeClass(!el.checked?"jsRadiobuttonActive":"");
	},
	rbClicked: function(el,nel){
		if(el){
			
			elName = el.getProperty("name")
			$$(".cfe_radio_"+elName).each(function(el){el.checked = false;});
			$$(".cfe_radiogroup_"+elName).each(function(el){el.fireEvent("mouseout");});
									
			el.checked = "true";
			nel.addClass("jsRadiobuttonActive").addClass("jsRadiobuttonHoverActive");
		}
	},
	rbChanged: function(el,nel){
		//console.log("%s has changed", el);	
	}
});