/*
customFormElements 1.6 - style checkboxes and radiobuttons on your own
by Maik Vlcek (http://www.mediavrog.net) - MIT-style license.
Copyright (c) 2007 Maik vlcek

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

var customFormElements = new Class({
	
	initialize: function(options){
		
		this.setOptions({
			scope: false,
			check: true,
			radio: true,
			spacer: "gfx/spacer.gif"
		}, options);
		
		this.options.check?this.initializeCheckboxes.bind(this)():"";
		this.options.radio?this.initializeRadiobuttons.bind(this)():"";
	},
	
	/* build aliases for checkboxes */
	initializeCheckboxes: function(){
		//console.log("call customCheckboxes");
		$ES("input[type=checkbox]",this.options.scope || document.body).each(function(el){
			
			/* create main checkbox alias */
			var jschb = new Element("span",{
									"class": "jsCheckbox",
									'events': {
										'mouseover': this.cbHover,
										'mouseout': this.cbMouseOut,
										"click":this.cbClicked
									}									
								}).injectBefore(el).adopt(new Element("img",{"src": this.options.spacer}));
			
			/* attach original input element to alias */
			jschb.input = el.setStyle("display","none");
				jschb.input.checked?jschb.addClass("jsCheckboxActive"):"";
			
			/* attach label to alias */
			jschb.label = $E("label[for="+el.getProperty("id")+"]").removeProperty("for").addClass("for_"+el.getProperty("id")+" jsCheckboxLabel").addEvents({"mouseover": this.cbHover.bind(jschb),"mouseout": this.cbMouseOut.bind(jschb),"click":this.cbClicked.bind(jschb)}) || false;
			
		}.bind(this));
	},
	
	/* Events for checkboxes */
	cbHover: function(){
		this.addClass(this.input.checked?"jsCheckboxHoverActive":"jsCheckboxHover");
		this.label?this.label.addClass("jsCheckboxLabelHover"):"";
	},
	cbMouseOut: function(){
		this.removeClass("jsCheckboxHoverActive").removeClass("jsCheckboxHover").removeClass(this.input.checked!=true?"jsCheckboxActive":"");
		this.label?this.label.removeClass("jsCheckboxLabelHover"):"";
	},
	cbClicked: function(where){
		this.fireEvent("mouseout");
		
		if(this.input.checked==true){
			this.input.removeProperty("checked");
			this.removeClass("jsCheckboxActive").removeClass("jsCheckboxHoverActive");
			this.addClass("jsCheckboxHover");
		}
		else{
			this.input.checked = true;
			this.addClass("jsCheckboxActive jsCheckboxHoverActive");
		}
	},
	
	/* build aliases for radiobuttons */
	initializeRadiobuttons: function(){	
		
		$ES("input[type=radio]",this.options.scope || document.body).each(function(el){
					
			var elName = el.getProperty("name").replace("]","").replace("[","-");
			
			/* create main radiobutton alias */
			var jschb = new Element("span",{
									"class": "jsRadiobutton cfe_radiogroup_"+elName,
									'events': {
										'mouseover': this.rbHover,
										'mouseout': this.rbMouseOut,
										"click":this.rbClicked
									}									
								}).injectBefore(el).adopt(new Element("img",{"src": this.options.spacer}));
			
			/* attach original input element to alias */
			jschb.input = el.setStyle("display","none");
			jschb.input.checked?jschb.addClass("jsRadiobuttonActive"):"";
			
			/* attach label to alias */
			jschb.label = $E("label[for="+el.getProperty("id")+"]").removeProperty("for").addClass("for_"+el.getProperty("id")+" jsRadiobuttonLabel").addEvents({"mouseover": this.rbHover.bind(jschb),"mouseout": this.rbMouseOut.bind(jschb),"click":this.rbClicked.bind(jschb)}) || false;

								 
		}.bind(this));
	},
	
	
	/* events for radiobuttons */
	rbHover: function(){
		this.addClass(this.input.checked?"jsRadiobuttonHoverActive":"jsRadiobuttonHover");
		this.label?this.label.addClass("jsRadiobuttonLabelHover"):"";
	},
	rbMouseOut: function(){
		this.removeClass("jsRadiobuttonHoverActive").removeClass("jsRadiobuttonHover").removeClass(this.input.checked!=true?"jsRadiobuttonActive":"");
		this.label?this.label.removeClass("jsRadiobuttonLabelHover"):"";
	},
	rbClicked: function(where){
			
		elName = this.input.getProperty("name").replace("]","").replace("[","-");
			
		$$(".cfe_radiogroup_"+elName).each(function(el){
			el.input.removeProperty("checked");
			el.fireEvent("mouseout");
		});
	
		this.input.checked = "true";
		this.addClass("jsRadiobuttonActive jsRadiobuttonHoverActive");
	}
});

customFormElements.implement(new Options,new Events);