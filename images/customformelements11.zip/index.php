<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Die ist eine Testseite f�r custom Form Elements - Checkboxen und Radiobuttons selbst per CSS gestalten / Test custom Form Elements</title>

<link rel="stylesheet" type="text/css" href="customFormElements.css" />
<script type="text/javascript" src="mootoolsMinimal.js"></script>
<script type="text/javascript" src="class.customFormElements.js"></script>
<script type="text/javascript">
window.addEvent('domready', function(){new customFormElements();});
</script>

</head>

<body>

<p>Dies ist eine Testseite f�r die Javascript-Klasse customFormElements, welche das Anpassen von Checkboxen und Radiobuttons per Javascript erm�glicht.</p>
<p>Dieses Script und die Ressourcen k�nnen frei verwendet werden. Grafiken der Buttons und Boxen in Anlehnung an den Opera :) .<a href="http://mediavrog.net/blog/2007/06/04/mootools/mootools-customformelements-checkboxen-und-radiobuttons-selbst-per-css-gestalten/" >Weitere Infomationen im Blog von mediaVROG erfahren</a>.

<hr />

<p>Postvariables:</p>
<pre>
<?php var_dump($_POST); ?>
</pre>

<form id="form" method="post" action="#">
<fieldset><legend>Replaced checkboxes</legend>
<ul>
	<li><label for="chb1">Checkbox #1 - checked by default</label><input type="checkbox" <?php if($_POST['checkbox1'] || $_SERVER['REQUEST_METHOD'] != "POST"){echo 'checked="checked" ';}?>value="Great!" name="checkbox1" />
		</li>

	<li><label for="chb1">Checkbox #2</label><input type="checkbox" <?php if($_POST['checkbox2']){echo 'checked="checked" ';}?>value="Wow!" name="checkbox2" />
		</li>

	<li><label for="chb1">Checkbox #3</label><input type="checkbox" value="Fascinating!" name="checkbox3" <?php if($_POST['checkbox3']){echo 'checked="checked" ';}?> />
		</li>

</ul>
</fieldset>

<fieldset><legend>Replaced radiobuttons</legend>
<ul>
	<li><label for="chb1">Radiobutton #1 - checked by default</label><input type="radio" <?php if($_POST['radio']=="Hooray!" || $_SERVER['REQUEST_METHOD'] != "POST"){echo 'checked="checked" ';}?>value="Hooray!" name="radio" />
		</li>

	<li><label for="chb1">Radiobutton #2</label><input type="radio" <?php if($_POST['radio'] == "Woot!"){echo 'checked="checked" ';}?>value="Woot!" name="radio" />
		</li>

	<li><label for="chb1">Radiobutton #3</label><input type="radio" value="Trembling!" name="radio" <?php if($_POST['radio'] == "Trembling!"){echo 'checked="checked" ';}?> />
		</li>

</ul>
</fieldset>

<fieldset><legend>2nd group of Replaced radiobuttons</legend>
<ul>
	<li><label for="chb1">Radiobutton #1 - checked by default</label><input type="radio" <?php if($_POST['radio2']=="2Hooray!" || $_SERVER['REQUEST_METHOD'] != "POST"){echo 'checked="checked" ';}?>value="2Hooray!" name="radio2" />
		</li>

	<li><label for="chb1">Radiobutton #2</label><input type="radio" <?php if($_POST['radio2'] == "2Woot!"){echo 'checked="checked" ';}?>value="2Woot!" name="radio2" />
		</li>

	<li><label for="chb1">Radiobutton #3</label><input type="radio" value="2Trembling!" name="radio2" <?php if($_POST['radio2'] == "2Trembling!"){echo 'checked="checked" ';}?> />
		</li>

</ul>
</fieldset>

<fieldset><legend>Check POST Data</legend>
<input type="submit" />
</fieldset>

</form>
</body></html>